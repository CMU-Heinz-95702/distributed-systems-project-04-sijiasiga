package mealapp.mealsearchandroid;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.List;
import java.util.Map;

/**
 * MainActivity for Meal & Drink Search App
 * Author: Sijia Ma (sijiam@andrew.cmu.edu)
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    // UI Components
    private Spinner typeSpinner;
    private EditText keywordInput;
    private Button searchButton;
    private TextView resultText;
    private ImageView resultImage;

    // API endpoint base URL
    private static final String BASE_URL = "https://probable-trout-q5wp4jwj9j6h94q6-8080.app.github.dev/api/search";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        typeSpinner = findViewById(R.id.typeSpinner);
        keywordInput = findViewById(R.id.keywordInput);
        searchButton = findViewById(R.id.searchButton);
        resultText = findViewById(R.id.resultText);
        resultImage = findViewById(R.id.resultImage);

        // Setup Spinner values
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.search_types, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        typeSpinner.setAdapter(adapter);

        /**
         * Set up search button click listener
         */
        searchButton.setOnClickListener(v -> performSearch());
    }

    /**
     * Perform API request in background and update UI
     */
    private void performSearch() {
        String type = typeSpinner.getSelectedItem().toString().toLowerCase();
        String keyword = keywordInput.getText().toString().trim();

        // Validate user input
        if (keyword.isEmpty()) {
            Toast.makeText(this, "Please enter a keyword", Toast.LENGTH_SHORT).show();
            return;
        }

        // Show loading status
        resultText.setText("Searching...");
        resultImage.setImageDrawable(null);

        // Background thread for HTTP request
        new Thread(() -> {
            try {
                // URL encode parameters
                String encodedKeyword = URLEncoder.encode(keyword, "UTF-8");
                String encodedType = URLEncoder.encode(type, "UTF-8");

                // Build URL
                String requestUrl = BASE_URL + "?type=" + encodedType + "&keyword=" + encodedKeyword;

                // Log the URL being requested
                Log.d(TAG, "Requesting URL: " + requestUrl);

                // First request
                URL url = new URL(requestUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(15000); // 15 seconds timeout
                conn.setReadTimeout(15000);
                conn.setRequestProperty("Accept", "application/json"); // Request JSON response

                // Important: disable automatic redirects
                conn.setInstanceFollowRedirects(false);

                // Get response code
                int responseCode = conn.getResponseCode();
                Log.d(TAG, "Response Code: " + responseCode);

                // Handle redirect (HTTP 302)
                if (responseCode == HttpURLConnection.HTTP_MOVED_TEMP ||
                        responseCode == HttpURLConnection.HTTP_MOVED_PERM ||
                        responseCode == HttpURLConnection.HTTP_SEE_OTHER) {

                    // Get the new location
                    String newUrl = conn.getHeaderField("Location");
                    Log.d(TAG, "Redirect to: " + newUrl);

                    // Get cookies
                    Map<String, List<String>> headers = conn.getHeaderFields();
                    List<String> cookies = headers.get("Set-Cookie");
                    String cookieString = "";

                    if (cookies != null) {
                        StringBuilder cookieBuilder = new StringBuilder();
                        for (String cookie : cookies) {
                            cookieBuilder.append(cookie).append("; ");
                        }
                        cookieString = cookieBuilder.toString();
                        Log.d(TAG, "Cookies: " + cookieString);
                    }

                    // Follow the redirect manually
                    URL redirectUrl = new URL(newUrl);
                    HttpURLConnection redirectConn = (HttpURLConnection) redirectUrl.openConnection();
                    redirectConn.setRequestMethod("GET");

                    // Set cookies if we have them
                    if (!cookieString.isEmpty()) {
                        redirectConn.setRequestProperty("Cookie", cookieString);
                    }

                    redirectConn.setConnectTimeout(15000);
                    redirectConn.setReadTimeout(15000);

                    int redirectResponseCode = redirectConn.getResponseCode();
                    Log.d(TAG, "Redirect Response Code: " + redirectResponseCode);

                    if (redirectResponseCode == HttpURLConnection.HTTP_OK) {
                        // Read the response
                        BufferedReader reader = new BufferedReader(new InputStreamReader(redirectConn.getInputStream()));
                        StringBuilder response = new StringBuilder();
                        String line;

                        while ((line = reader.readLine()) != null) {
                            response.append(line);
                        }
                        reader.close();

                        String jsonResponse = response.toString();
                        Log.d(TAG, "Redirect Response (first 100 chars): " +
                                jsonResponse.substring(0, Math.min(100, jsonResponse.length())));

                        parseJSONResponse(type, jsonResponse);
                    } else {
                        runOnUiThread(() -> {
                            resultText.setText("Error: Redirect failed with code " + redirectResponseCode);
                        });
                    }
                } else if (responseCode == HttpURLConnection.HTTP_OK) {
                    // Direct successful response
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;

                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();

                    String jsonResponse = response.toString();
                    Log.d(TAG, "Response (first 100 chars): " +
                            jsonResponse.substring(0, Math.min(100, jsonResponse.length())));

                    parseJSONResponse(type, jsonResponse);
                } else {
                    // Error response
                    runOnUiThread(() -> {
                        resultText.setText("Error: Server returned code " + responseCode);
                    });
                }
            } catch (Exception e) {
                e.printStackTrace();
                final String errorMessage = e.getMessage();
                runOnUiThread(() -> {
                    resultText.setText("Error: " + errorMessage);
                    Toast.makeText(MainActivity.this, "Network Error", Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    /**
     * Parse JSON response and update UI
     */
    private void parseJSONResponse(String type, String json) {
        Handler handler = new Handler(Looper.getMainLooper());

        handler.post(() -> {
            try {
                JSONObject jsonObject = new JSONObject(json);

                if (type.equals("meal") && jsonObject.has("meals") && !jsonObject.isNull("meals")) {
                    JSONArray meals = jsonObject.getJSONArray("meals");

                    if (meals.length() > 0) {
                        JSONObject meal = meals.getJSONObject(0);

                        String name = meal.getString("strMeal");
                        String imageUrl = meal.getString("strMealThumb");
                        String category = meal.optString("strCategory", "N/A");
                        String area = meal.optString("strArea", "N/A");

                        String display = name + "\nCategory: " + category + "\nArea: " + area;
                        resultText.setText(display);
                        Picasso.get().load(imageUrl).into(resultImage);
                    } else {
                        resultText.setText("No meals found for: " + keywordInput.getText().toString());
                        resultImage.setImageDrawable(null);
                    }
                } else if (type.equals("drink") && jsonObject.has("drinks") && !jsonObject.isNull("drinks")) {
                    JSONArray drinks = jsonObject.getJSONArray("drinks");

                    if (drinks.length() > 0) {
                        JSONObject drink = drinks.getJSONObject(0);

                        String name = drink.getString("strDrink");
                        String imageUrl = drink.getString("strDrinkThumb");
                        String category = drink.optString("strCategory", "N/A");
                        String alcoholic = drink.optString("strAlcoholic", "N/A");

                        String display = name + "\nCategory: " + category + "\nAlcoholic: " + alcoholic;
                        resultText.setText(display);
                        Picasso.get().load(imageUrl).into(resultImage);
                    } else {
                        resultText.setText("No drinks found for: " + keywordInput.getText().toString());
                        resultImage.setImageDrawable(null);
                    }
                } else {
                    resultText.setText("No results found.");
                    resultImage.setImageDrawable(null);
                }
            } catch (Exception e) {
                resultText.setText("Error parsing response: " + e.getMessage());
                resultImage.setImageDrawable(null);
                Log.e(TAG, "Parse error: " + e.getMessage());
                e.printStackTrace();
            }
        });
    }
}